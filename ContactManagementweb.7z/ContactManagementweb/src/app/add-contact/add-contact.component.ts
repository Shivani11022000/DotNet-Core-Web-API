import { Component } from '@angular/core';

@Component({
  selector: 'app-add-contact',
  standalone: true,
  imports: [],
  templateUrl: './add-contact.component.html',
  styleUrl: './add-contact.component.css'
})
export class AddContactComponent {

}
