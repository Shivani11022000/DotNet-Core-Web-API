

// contact-list.component.ts
import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {
  contacts: any[] = [];
  favoriteContacts: any[] = [];
  searchQuery: string = '';
  newContact: any = {
    name: '',
    email: '',
    phone: '',
    password: ''
  };
  confirmPassword: string = '';

  constructor(private contactService: ContactService) { }

  ngOnInit(): void {
    this.loadContacts();
  }

  loadContacts() {
    this.contactService.getContacts().subscribe((data) => {
      this.contacts = data;
      this.favoriteContacts = this.contacts.filter(contact => contact.favorite);
    });
  }

  addContact() {
    if (this.newContact.password !== this.confirmPassword) {
      alert("Passwords do not match!");
      return;
    }
    this.contactService.addContact(this.newContact).subscribe(() => {
      this.newContact = {
        name: '',
        email: '',
        phone: '',
        password: ''
      };
      this.confirmPassword = '';
      this.loadContacts();
    });
  }

  editContact(contact: any) {
    // Implement edit logic
  }

  deleteContact(contact: any) {
    // Implement delete logic
  }

  toggleFavorite(contact: any) {
    contact.favorite = !contact.favorite;
    this.contactService.updateContact(contact).subscribe(() => {
      this.loadContacts();
    });
  }

  searchContacts() {
    // Implement search logic
  }
}
